<!--     WP Section Start    -->
<!doctype html>
<html lang="en">
    <head>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
        <meta charset="utf-8">
        <title><?php wp_title(); ?></title>
        <?php wp_head(); ?>
    </head>
<body id="bootstrap-overrides">      
    <!-- Header & Navigation -->
    <nav class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php bloginfo('url'); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/templogo.png" alt="logo"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
            <?php
              $defaults = array(
                'container' => false, 
                'theme_location' => 'main-menu',
                'menu_class' => 'nav navbar-nav',
              );
            wp_nav_menu( $defaults )
            ?>

            </div>
        </div>
    </nav> 
<!--     WP Section End     -->   