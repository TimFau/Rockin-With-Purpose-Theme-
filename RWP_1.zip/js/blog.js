/*jslint browser: true*/
/*global $, jQuery, alert*/
jQuery(".latestposts").stick_in_parent();