<!--     WP Section Start    -->
    <!-- Footer -->
    <div class="container footer">
            <div>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="">Twitter</a></li>
                    <li><a href="">Facebook</a></li>
                    <li><a href="about.html">About</a></li>
                </ul> 
                <p>©<?php echo date('Y'); ?> Rockin' With Purpose</p>
                <p>Designed by <a href="http://FauDesign.com">Tim Fau</a></p>
            </div>
        </div>

    <?php wp_footer(); ?>

</body>
</html>
<!--     WP Section End    -->