<?php get_header(); ?>

<div class="header_post_float">
    
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    
        <div class="blogheader">
            <div class="blogimg"><img src="img/slider/night.jpg"></div>
            <div class="blogtitle">
                <div class="postcategory"><a href="#">Features</a></div>
                <div class="postcategory"><a href="#">Lists</a></div>
                <div class="blogtitleh1"><h1><?php the_title(); ?></h1></div>
                <div class="blogmetainfo"><p>Posted by<a href="#"> Linda</a> | August 25 2016</p></div>
            </div>
        </div>
        <div class="post">
            <p><?php the_content(); ?></p>
        </div>
    
        <?php endwhile; else : ?>
	        <p><?php _e( 'Sorry, no pages found.' ); ?></p>
        <?php endif; ?>
    
</div>

<?php get_footer(); ?>